#include "datalogprogram.h"

std::string Predicate::toString() {
	std::ostringstream os;
	os << identifier << "(";

	for (uint i = 0; i < param_list.size(); i++) {
		auto param = param_list[i];
		os << param.toString();

		if ((i + 1) != param_list.size()) {
			// last iteration
			os << ",";
		}
	}

	os << ")";

	return os.str();
}

void Predicate::determineDomain(std::set<std::string>* domain) {
	for (auto param : param_list) {
		param.determineDomain(domain);
	}
}

std::string Rule::toString() {
	std::ostringstream os;
	os << predicate.toString() << " :- ";

	for (uint i = 0; i < predicate_list.size(); i++) {
		auto predicate = predicate_list[i];

		os << predicate.toString();

		if ((i + 1) != predicate_list.size()) {
			// last iteration
			os << ",";
		}
	}

	return os.str();
}

void Rule::determineDomain(std::set<std::string>* domain) {
	for (auto p : predicate_list) {
		p.determineDomain(domain);
	}
}

std::string Parameter::toString() {
	std::ostringstream os;

	if (type == STRING) {
		os << "'" << str << "'";
	} else if (type == ID) {
		os << str;
	}

	return os.str();
}

void Parameter::determineDomain(std::set<std::string>* domain) {
	if (type == STRING) {
		domain->insert(str);
	}
}

void DatalogProgram::determineDomain() {
	for (auto s : scheme_list)
		s.determineDomain(&domain);

	for (auto f : fact_list)
		f.determineDomain(&domain);

	for (auto r : rule_list)
		r.determineDomain(&domain);

	for (auto q : query_list)
		q.determineDomain(&domain);
}

std::string DatalogProgram::toString() {
	std::ostringstream os;

	os << "Schemes(" << scheme_list.size() << "):" << std::endl;
	for (auto s : scheme_list) {
		os << "  " << s.toString() << std::endl;
	}

	os << "Facts(" << fact_list.size() << "):" << std::endl;
	for (auto f : fact_list) {
		os << "  " << f.toString() << std::endl;
	}

	os << "Rules(" << rule_list.size() << "):" << std::endl;
	for (auto r : rule_list) {
		os << "  " << r.toString() << std::endl;
	}

	os << "Queries(" << query_list.size() << "):" << std::endl;
	for (auto q : query_list) {
		os << "  " << q.toString() << std::endl;
	}

	os << "Domain(" << domain.size() << "):" << std::endl;
	for (auto str : domain) {
		os << "  '" << str << "'" << std::endl;
	}

	return os.str();
}
